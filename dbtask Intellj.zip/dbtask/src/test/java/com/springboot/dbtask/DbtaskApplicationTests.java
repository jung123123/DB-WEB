package com.springboot.dbtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbtaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
