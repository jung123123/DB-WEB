package com.springboot.dbtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbtaskApplication.class, args);
	}

}
